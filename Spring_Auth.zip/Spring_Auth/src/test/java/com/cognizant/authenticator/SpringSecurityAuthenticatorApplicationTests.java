package com.cognizant.authenticator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityAuthenticatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
